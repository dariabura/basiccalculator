from setuptools import setup, find_packages

setup(
name='calculator',
version='0.1',
description='this is a simple calculator',
author='daria',
author_email= 'dburakowska1@st.swps.edu.pl',
License='unlicense',
package='basiccalculator', 
zip_safe=False
)
